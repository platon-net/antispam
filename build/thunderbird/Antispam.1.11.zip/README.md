<img src="images/icon.svg" width="32" height="32" alt="Logo"> Antispam
========
Send e-mail to antispam database from Thunderbird.

Installation from Mozilla Addons
================================
Go to [https://addons.thunderbird.net/sk/thunderbird/addon/antispam/](https://addons.thunderbird.net/sk/thunderbird/addon/antispam/) or search "Platon Antispam"

Installation from file
======================
* In Thunderbird open on new tab "about:config" and type "xpinstall.signatures.required" where change to "false"
* Download build/thunderbird/Antispam.latest_version.zip
* In Thunderbird open plugins and install from downloaded ZIP file

FEATURES
========
Plugin required connection to API.

PRIVACY
=======
When you click on the Antispam button on the displayed email, it sends meta-data, the sender's email, the IP address and the subject of the email.
